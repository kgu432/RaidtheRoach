The game is called Raid the Roach. Disaster has struck! The roaches have infested your apartment :(

    OBJECTIVE: 
    - You need to use the raid bottle on the screen and try to "spray" the roach, which means you need to line the spray can on top of the roach.
    - The roach will disappear and reappear in a randomized spot on the screen every 1.25 seconds, and you have 15 seconds to spray the roach. 

    CONTROLS: 
    - You can use the arrow keys to navigate across the screen

GOOD LUCK!!