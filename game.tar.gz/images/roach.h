/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=23x16 roach roach.png 
 * Time-stamp: Tuesday 11/08/2022, 05:40:35
 * 
 * Image Information
 * -----------------
 * roach.png 23@16
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef ROACH_H
#define ROACH_H

extern const unsigned short roach[368];
#define ROACH_SIZE 736
#define ROACH_LENGTH 368
#define ROACH_WIDTH 23
#define ROACH_HEIGHT 16

#endif

