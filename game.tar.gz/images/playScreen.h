/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 playScreen playScreen.png 
 * Time-stamp: Sunday 11/06/2022, 00:42:33
 * 
 * Image Information
 * -----------------
 * playScreen.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PLAYSCREEN_H
#define PLAYSCREEN_H

extern const unsigned short playScreen[38400];
#define PLAYSCREEN_SIZE 76800
#define PLAYSCREEN_LENGTH 38400
#define PLAYSCREEN_WIDTH 240
#define PLAYSCREEN_HEIGHT 160

#endif

