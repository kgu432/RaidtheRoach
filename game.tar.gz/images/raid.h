/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=9x23 raid raid.png 
 * Time-stamp: Tuesday 11/08/2022, 05:40:13
 * 
 * Image Information
 * -----------------
 * raid.png 9@23
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef RAID_H
#define RAID_H

extern const unsigned short raid[207];
#define RAID_SIZE 414
#define RAID_LENGTH 207
#define RAID_WIDTH 9
#define RAID_HEIGHT 23

#endif

